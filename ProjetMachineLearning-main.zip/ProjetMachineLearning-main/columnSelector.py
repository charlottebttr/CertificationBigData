import pandas as pd

class ColumnSelector :
    def __init__(self):
        self.donnees_propres = pd.read_csv("./cleanData.csv",encoding="latin-1")
        self.donnees_completes = pd.read_csv("./recipeData.csv",encoding="latin-1")
    
    def selectionne_colonnes(self, colonnes_a_selectionner:list, propre:bool) -> pd.DataFrame : 
        if propre : 
            dataframe = self.donnees_propres[colonnes_a_selectionner]
        else :
            dataframe = self.donnees_completes[colonnes_a_selectionner]
        
        return dataframe
