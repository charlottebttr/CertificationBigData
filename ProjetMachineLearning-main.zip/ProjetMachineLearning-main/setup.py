import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import classifieurColor, classifieurStyle, classifieurBrewMethod

SEUIL_POURCENTAGE_MANQUANT = 0.05
SEUIL_IBU = 100
SEUIL_ABV = 15
SEUIL_OG = 1.5
SEUIL_SIZE = 2000

def compte_valeurs_manquantes(colonne) :
    return colonne.isna().sum()

def supprimer_colonnes_presque_vides(dataframe:pd.DataFrame) -> pd.DataFrame :
    for colonne in dataframe.columns :
        valeurs_manquantes = compte_valeurs_manquantes(dataframe[colonne])
        print(valeurs_manquantes)
        if (valeurs_manquantes/len(dataframe[colonne])) > SEUIL_POURCENTAGE_MANQUANT :
            print("Suppression de :", colonne)
            dataframe = dataframe.drop(columns=[colonne])    
    return dataframe

def supprime_colonnes(dataframe:pd.DataFrame) -> pd.DataFrame : 
    nouveau_dataframe = supprimer_colonnes_presque_vides(dataframe)
    return nouveau_dataframe

def supprime_lignes(dataframe:pd.DataFrame) -> pd.DataFrame :
    dataframe.dropna(inplace=True)
    print(f'Jeu de données sans lignes vides, {len(dataframe.index)} lignes')
    dataframe = dataframe[dataframe['IBU']<SEUIL_IBU]
    print(f'Jeu de données sans IBU trop élevé, {len(dataframe.index)} lignes')
    dataframe = dataframe[dataframe['ABV']<SEUIL_ABV]
    print(f'Jeu de données sans ABV trop élevé, {len(dataframe.index)} lignes')
    dataframe = dataframe[dataframe['OG']<SEUIL_OG]
    print(f'Jeu de données sans OG trop élevé, {len(dataframe.index)} lignes')
    dataframe = dataframe[dataframe['Size(L)']<SEUIL_SIZE]
    return dataframe

def enregistrer_csv(dataframe:pd.DataFrame) :
    dataframe.to_csv("cleanData.csv",index=False)

def ajoute_classe_couleur(dataframe:pd.DataFrame) -> pd.DataFrame :
    classifieur = classifieurColor.ClassifieurColor()
    liste_classes_biere = []
    for biere in dataframe['Color'] :
        liste_classes_biere.append(classifieur.classe_biere(biere))
    dataframe['BeerClass'] = liste_classes_biere
    return dataframe

def ajoute_style_biere(dataframe:pd.DataFrame) -> pd.DataFrame :
    classifieur = classifieurStyle.ClassifieurStyle()
    liste_classes_biere = []
    for biere in dataframe['Style'] :
        liste_classes_biere.append(classifieur.classe_biere(biere))
    dataframe['StyleCategory'] = liste_classes_biere
    return dataframe

def ajoute_calcul_ogfg(dataframe : pd.DataFrame) -> pd.DataFrame :
    dataframe['OGFG'] = dataframe['OG'] - dataframe['FG']
    return dataframe

def ajoute_numero_biere(dataframe:pd.DataFrame) -> pd.DataFrame :
    classifieur = classifieurStyle.ClassifieurStyle()
    liste_numero_biere = []
    for biere in dataframe['Style'] :
        liste_numero_biere.append(classifieur.numero_biere(biere))
    dataframe['NumStyleCategory'] = liste_numero_biere
    return dataframe

def ajoute_numero_methode(dataframe:pd.DataFrame) -> pd.DataFrame :
    classifieur = classifieurBrewMethod.ClassifieurBrewMethod()
    liste_numero_methode = []
    for methode in dataframe['BrewMethod'] :
        liste_numero_methode.append(classifieur.numero_methode(methode))
    dataframe['NumBrewMethod'] = liste_numero_methode
    return dataframe

def ajoute_donnees_calculees(dataframe:pd.DataFrame) -> pd.DataFrame :
    nouveau_dataframe = ajoute_classe_couleur(dataframe)
    autre_dataframe = ajoute_style_biere(nouveau_dataframe)
    autre_dataframe1 = ajoute_numero_biere(autre_dataframe)
    autre_dataframe2 = ajoute_numero_methode(autre_dataframe1)
    dataframe_avec_ogfg = ajoute_calcul_ogfg(autre_dataframe2)
    return dataframe_avec_ogfg

def scale_donnees(dataframe : pd.DataFrame) -> pd.DataFrame :
    dataframe['IBUoriginel']=dataframe['IBU']
    scaler = MinMaxScaler(feature_range=(0,1))
    df_numerique = dataframe[['Color', 'BoilSize', 'BoilTime', 'BoilGravity', 'Efficiency','OGFG','IBUoriginel']]
    scaler.fit(df_numerique)
    df_numerique_scaled = scaler.transform(df_numerique)
    dataframe[["Color","BoilSize","BoilTime","BoilGravity","Efficiency",'OGFG','IBU']] = df_numerique_scaled
    return dataframe

#Création du dataframe sur la base du fichier .csv source
dataframe = pd.read_csv("./recipeData.csv",encoding="latin-1")
print(f'Jeu de données initial, {len(dataframe.index)} lignes')
nouveau_dataframe = supprime_colonnes(dataframe)
dataframe_sans_lignes_vides = supprime_lignes(nouveau_dataframe)
dataframe_renseigne = ajoute_donnees_calculees(dataframe_sans_lignes_vides)
# dataframe_scaled = scale_donnees(dataframe_renseigne)
enregistrer_csv(dataframe_renseigne)
# print(f'Jeu de données propre enregistré, {len(dataframe_scaled.index)} lignes')