import matplotlib.pyplot as plt
import pandas as pd
import missingno as msno
import seaborn as sns
import numpy as np

class GraphDesigner:

    def __init__(self):
        pass
    
    def dessine_graphes(self, dataframe : pd.DataFrame, type_graphes:str, variable_a_observer : str = None) :
        self.dataframe = dataframe        
        match type_graphes : 
            case "missing":
                msno.matrix(self.dataframe)
                plt.show()
            case 'box':
                self.dataframe.boxplot()
                plt.tight_layout()
                plt.show()
            case 'hist':
                self.dataframe.hist()
                plt.tight_layout()
                plt.show()
            case 'heatmap':
                sns.heatmap(dataframe, annot=True, cmap='coolwarm', center=0)
                plt.title('Heatmap de la matrice de correlation des variables numériques utiles')
                plt.show()
            case 'bar':
                df = dataframe[variable_a_observer].value_counts()
                df.plot(kind='bar',color='skyblue')
                plt.xticks(rotation=0)
                plt.title('Répartition des types de variables')
                plt.show()
            case 'pie':
                df = dataframe[variable_a_observer].value_counts()
                df.plot(kind='pie',cmap='coolwarm',ylabel='',autopct='%1.1f%%')
                plt.xticks(rotation=0)
                plt.xlabel(f'{variable_a_observer}')
                plt.title('Répartition des types de variables')
                plt.show()
            case 'regplot':
                donnees_1 = dataframe['IBU']
                donnees_2 = dataframe['ABV']
                sns.regplot(x=donnees_1,y=donnees_2,data=dataframe)
                plt.show()
            case _:
                pass