import sklearn.linear_model as model
import sklearn.ensemble as ens
import pandas as pd
import classifieurBrewMethod
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.preprocessing import MinMaxScaler
import statsmodels.api as sm
import matplotlib.pyplot as plt



SEUIL_TAILLE_ENTRAINEMENT = 0.8

class Predicteur:

    def __init__(self, dataframe : pd.DataFrame):
        self.logistic = model.LogisticRegression()
        self.linear = model.LinearRegression()
        self.foret = ens.RandomForestClassifier()
        self.foretReg = ens.RandomForestRegressor(n_estimators=10, random_state=40)
        self.dataframe = dataframe
        
        self.quantite_donnees =len(self.dataframe.index)
        self.nombre_donnees_entrainement = int(self.quantite_donnees*SEUIL_TAILLE_ENTRAINEMENT)
        self.nombre_donnees_teste = int(round(len(self.dataframe.index)*(1-SEUIL_TAILLE_ENTRAINEMENT),0))
    
    def predit_abv(self):
        X = self.dataframe[["Color","BoilSize","BoilTime","BoilGravity","Efficiency",'OGFG','IBU','NumBrewMethod']]
        # X = self.dataframe[["Color","BoilSize","BoilTime","BoilGravity","Efficiency",'IBUoriginel','NumBrewMethod']]
        y = self.dataframe['ABV']
        X_train = X.head(self.nombre_donnees_entrainement)
        X_test = X.tail(self.nombre_donnees_teste)
        Y_test = y.tail(self.nombre_donnees_teste)
        self.foretReg.fit(X_train, y.head(self.nombre_donnees_entrainement))
        predictions = self.foretReg.predict(X_test)
        mse = mean_squared_error(Y_test, predictions)
        mae = mean_absolute_error(Y_test, predictions)
        r2 = r2_score(Y_test, predictions)
        # Résidus
        residuals = Y_test - predictions
        
        for pred in predictions:
            print(pred)
        print('Prédictions :',predictions)
        print('Coefs :',self.foretReg.feature_importances_)
        print("Mean Squared Error:", mse)
        print("Mean Absolute Error:", mae)
        print("R² Score:", r2)

        # Calculer l'autocorrélation des résidus
        autocorrelation = sm.tsa.acf(residuals, nlags=10)
        print("Autocorrélation des résidus :", autocorrelation)
        sm.graphics.tsa.plot_acf(residuals, lags=10)
        plt.show()
        return predictions
    
    def predit_ibu(self):
        # X = self.dataframe[["Color","BoilSize","BoilTime","BoilGravity","Efficiency",'OGFG','ABV','NumBrewMethod']]
        X = self.dataframe[["Color","BoilSize","BoilTime","BoilGravity","Efficiency",'OGFG','NumBrewMethod']]
        y = self.dataframe['IBU']
        X_train = X.head(self.nombre_donnees_entrainement)
        X_test = X.tail(self.nombre_donnees_teste)
        Y_test = y.tail(self.nombre_donnees_teste)
        self.foretReg.fit(X_train, y.head(self.nombre_donnees_entrainement))
        predictions = self.foretReg.predict(X_test)
        mse = mean_squared_error(Y_test, predictions)
        mae = mean_absolute_error(Y_test, predictions)
        r2 = r2_score(Y_test, predictions)
        # Résidus
        residuals = Y_test - predictions

        for pred in predictions:
            print(pred)
        print('Prédictions :',predictions)
        print('Coefs :',self.foretReg.feature_importances_)
        print("Mean Squared Error:", mse)
        print("Mean Absolute Error:", mae)
        print("R² Score:", r2)

        # Calculer l'autocorrélation des résidus
        autocorrelation = sm.tsa.acf(residuals, nlags=10)
        print("Autocorrélation des résidus :", autocorrelation)
        sm.graphics.tsa.plot_acf(residuals, lags=10)
        plt.show()
        return predictions
    
    def predit_abv_unique(self, selectionCara, boilSize, boilTime, boilGravity, og, fg, brewMethod):
        classifieur = classifieurBrewMethod.ClassifieurBrewMethod()
        data = {
            'BoilSize': [float(boilSize)],
            'BoilTime': [float(boilTime)],
            'BoilGravity': [float(boilGravity)],
            'OGFG': [float(og) - float(fg)]
        }
        dataframe_donnees_utilisateur = pd.DataFrame(data)
        dataframe_donnees_utilisateur["BoilSize"] = boilSize
        dataframe_donnees_utilisateur['BoilTime'] = boilTime
        dataframe_donnees_utilisateur['BoilGravity'] = boilGravity
        dataframe_donnees_utilisateur['OGFG'] = float(og) - float(fg)
        brewMethod_classifiee = classifieur.numero_methode(brewMethod)
        dataframe_donnees_utilisateur['NumBrewMethod'] = brewMethod_classifiee
        # scaler = MinMaxScaler(feature_range=(0,1))
        # df_numerique = dataframe_donnees_utilisateur[['BoilSize', 'BoilTime', 'BoilGravity','OGFG']]
        # scaler.fit(df_numerique)
        # df_numerique_scaled = scaler.transform(df_numerique)
        # dataframe_donnees_utilisateur[['BoilSize', 'BoilTime', 'BoilGravity','OGFG']] = df_numerique_scaled
        print(dataframe_donnees_utilisateur)

        X = self.dataframe[["BoilSize","BoilTime","BoilGravity",'OGFG','NumBrewMethod']]
        y = self.dataframe['ABV']
        X_train = X
        X_test = dataframe_donnees_utilisateur[["BoilSize","BoilTime","BoilGravity",'OGFG','NumBrewMethod']]
        self.foretReg.fit(X_train, y)
        predictions = self.foretReg.predict(X_test)
        
        for pred in predictions:
            print(pred)
        print('Prédictions :',predictions)
        print('Coefs :',self.foretReg.feature_importances_)
        return predictions
    
    def predit_ibu_unique(self, selectionCara, boilSize, boilTime, boilGravity, og, fg, brewMethod):
        classifieur = classifieurBrewMethod.ClassifieurBrewMethod()
        data = {
            'BoilSize': [float(boilSize)],
            'BoilTime': [float(boilTime)],
            'BoilGravity': [float(boilGravity)],
            'OGFG': [float(og) - float(fg)]
        }
        dataframe_donnees_utilisateur = pd.DataFrame(data)
        dataframe_donnees_utilisateur["BoilSize"] = boilSize
        dataframe_donnees_utilisateur['BoilTime'] = boilTime
        dataframe_donnees_utilisateur['BoilGravity'] = boilGravity
        dataframe_donnees_utilisateur['OGFG'] = float(og) - float(fg)
        brewMethod_classifiee = classifieur.numero_methode(brewMethod)
        dataframe_donnees_utilisateur['NumBrewMethod'] = brewMethod_classifiee
        # scaler = MinMaxScaler(feature_range=(0,1))
        # df_numerique = dataframe_donnees_utilisateur[['BoilSize', 'BoilTime', 'BoilGravity','OGFG']]
        # scaler.fit(df_numerique)
        # df_numerique_scaled = scaler.transform(df_numerique)
        # dataframe_donnees_utilisateur[['BoilSize', 'BoilTime', 'BoilGravity','OGFG']] = df_numerique_scaled
        print(dataframe_donnees_utilisateur)

        X = self.dataframe[["BoilSize","BoilTime","BoilGravity",'OGFG','NumBrewMethod']]
        y = self.dataframe['IBU']
        X_train = X
        X_test = dataframe_donnees_utilisateur
        self.foretReg.fit(X_train, y)
        predictions = self.foretReg.predict(X_test)
        self.foretReg.fit(X_train, y)
        predictions = self.foretReg.predict(X_test)
        
        for pred in predictions:
            print(pred)
        print('Prédictions :',predictions)
        print('Coefs :',self.foretReg.feature_importances_)
        return predictions
    
    def predit_all(self, variable_a_observer : str = None):
        X = self.dataframe[["Color","BoilSize","BoilTime","BoilGravity","Efficiency",'OGFG','IBUoriginel','NumBrewMethod']]
        y = self.dataframe[variable_a_observer]
        X_train = X.head(self.nombre_donnees_entrainement)
        X_test = X.tail(self.nombre_donnees_teste)
        Y_test = y.tail(self.nombre_donnees_teste)
        self.foretReg.fit(X_train, y.head(self.nombre_donnees_entrainement))
        predictions = self.foretReg.predict(X_test)
        mse = mean_squared_error(Y_test, predictions)
        mae = mean_absolute_error(Y_test, predictions)
        r2 = r2_score(Y_test, predictions)

        for pred in predictions:
            print(pred)
        print('Prédictions :',predictions)
        print('Coefs :',self.foretReg.feature_importances_)
        print("Mean Squared Error:", mse)
        print("Mean Absolute Error:", mae)
        print("R² Score:", r2)
        return predictions