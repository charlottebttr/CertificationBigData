import columnSelector
import graphDesigner
import predicteur
import pandas as pd
from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/resultGraph', methods=['POST'])
def resultGraph():
    selectionGraph = request.form['selectionGraph']
    selectionCara = ''
    varAObs = request.form['variableAObsrever']
    boilSize = ''
    boilTime = ''
    boilGravity = ''
    og = ''
    fg = ''
    brewMethod = ''
    
    result = main(selectionGraph, selectionCara, varAObs, boilSize, boilTime, boilGravity, og, fg, brewMethod)
    
    return f"Résultat : {result}"

@app.route('/resultCara', methods=['POST'])
def resultCara():
    selectionGraph = ''
    selectionCara = request.form['selectionCara']
    varAObs = ''
    boilSize = request.form['BoilSize']
    boilTime = request.form['BoilTime']
    boilGravity = request.form['BoilGravity']
    og = request.form['OG']
    fg = request.form['FG']
    brewMethod = request.form['BrewMethod']
    
    result = main(selectionGraph, selectionCara, varAObs, boilSize, boilTime, boilGravity, og, fg, brewMethod)
    
    return f"Résultat : {result}"

def main(selectionGraph, selectionCara, varAObs, boilSize, boilTime, boilGravity, og, fg, brewMethod):

    selecteur_colonnes = columnSelector.ColumnSelector()
    dessinateur_graphes = graphDesigner.GraphDesigner()

    colonnes_utiles = ["OG","FG","ABV","IBU","Color",'BeerClass','StyleCategory','OGFG','BoilSize','BoilTime','BoilGravity', 'Efficiency',"NumBrewMethod"]
    colonnes_numeriques = ["OG","FG","ABV","IBU","Color","BoilSize","BoilTime","BoilGravity","Efficiency","NumBrewMethod",'OGFG']
    colonnes_categorielles = ["Name","URL","Style","SugarScale","BrewMethod",'BeerClass','StyleCategory']
    toutes_colonnes = ["BeerID","Name","URL","Style","StyleID","Size(L)","OG","FG","ABV","IBU","Color",
    "BoilSize","BoilTime","BoilGravity","Efficiency","MashThickness","SugarScale","BrewMethod","PitchRate",
    "PrimaryTemp","PrimingMethod","PrimingAmount","UserId"]

    dataframe = pd.DataFrame() 
    dataframe = selecteur_colonnes.selectionne_colonnes(toutes_colonnes,False)
    print(dataframe.describe())

    df_num = selecteur_colonnes.selectionne_colonnes(colonnes_numeriques,True)
    df_propre = selecteur_colonnes.selectionne_colonnes(colonnes_utiles,True)

    resultat = 'Pas de prédiction'

    match selectionGraph:
        case "missing":
            dessinateur_graphes.dessine_graphes(dataframe, "missing")
        case 'box':
            dessinateur_graphes.dessine_graphes(dataframe.describe(), "box")
        case 'hist':
            dessinateur_graphes.dessine_graphes(df_num.describe(), "hist")
        case 'heatmap':
            dessinateur_graphes.dessine_graphes(df_num.corr(), "heatmap")
        case 'bar':
            if(varAObs != ''):
                dessinateur_graphes.dessine_graphes(df_propre, "bar", varAObs)
            else:
                return 'Variable manquante'
        case 'pie':
            if(varAObs != ''):
                dessinateur_graphes.dessine_graphes(df_propre, "pie", varAObs)
            else:
                return 'Variable manquante'
        case 'regplot':
            dessinateur_graphes.dessine_graphes(df_num, "regplot")
        case _:
            pass

    match selectionCara:
        case "ABV":
            predicteur_bieres = predicteur.Predicteur(df_propre)
            resultat = predicteur_bieres.predit_abv_unique(selectionCara, boilSize, boilTime, boilGravity, og, fg, brewMethod)
        case 'IBU':
            predicteur_bieres = predicteur.Predicteur(df_propre)
            resultat = predicteur_bieres.predit_ibu_unique(selectionCara, boilSize, boilTime, boilGravity, og, fg, brewMethod)
        case 'IBU Historique':
            predicteur_bieres = predicteur.Predicteur(df_propre)
            resultat = predicteur_bieres.predit_ibu()
            resultat = resultat.round(2).tolist()
        case 'ABV Historique':
            predicteur_bieres = predicteur.Predicteur(df_propre)
            resultat = predicteur_bieres.predit_abv()
            resultat = resultat.round(2).tolist()
        case _:
            pass

    return f"Résultats de la prédiction : {resultat}"

if __name__ == '__main__':
    app.run(debug=True)