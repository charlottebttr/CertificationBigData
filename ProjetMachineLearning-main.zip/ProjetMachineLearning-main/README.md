# ProjetMachineLearning
Par Assad Kleit, Charlotte Bouttier et Adrien Dehais

Pour utiliser cette application, il faut télécharger le .zip de ce GitHub
Dézipper le contenu, sans déplacer les éléments dézippés
Suivre les instructions de Fonctionnement

## Librairies nécessaires
- pandas
- scikit_learn
- matplotlib
- missingno
- seaborn
- numpy
- flask
- statsmodels

## Fonctionnement
S'assurer que le fichier de données ne soit pas ouvert par une application
Executer setup.py en premier
Executer main.py ensuite
Se connecter à http://localhost:5000/ sur un navigateur web pour utiliser l'interface