class ClassifieurColor:
    def __init__(self):
        self.pale = 10
        self.ambree = 30
        self.brune = 40

    def classe_biere(self, couleur : float) -> str :
        result = ''
        if couleur <= self.pale:
            result = 'Pale'
        elif (couleur > self.pale) and (couleur <= self.ambree) :
            result = 'Ambree'
        elif (couleur > self.ambree) and (couleur <= self.brune) :
            result = 'Brune'
        else :
            result = 'Noire'
        return result