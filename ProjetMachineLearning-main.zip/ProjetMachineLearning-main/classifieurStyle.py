class ClassifieurStyle:
    def __init__(self):
        self.lager = 'Lager'
        self.ipa = 'IPA'
        self.saison = 'Season'
        self.stout = 'Stout'
        self.porter = 'Porter'
        self.sour = 'Sour'
        self.white = 'White'
        self.ale = 'Ale'
        self.other = 'Other'

    def classe_biere(self, style : str) -> str :
        result = ''
        if (style.find('Pils') != -1) or (style.find('Lager') != -1):
            result = self.lager
        elif (style.find('IPA') != -1) or (style.find('Indian Pale Ale') != -1) :
            result = self.ipa
        elif (style.find('Saison') != -1) or (style.find('Season') != -1) :
            result = self.saison
        elif (style.find('Stout') != -1):
            result = self.stout
        elif (style.find('Porter') != -1):
            result = self.porter
        elif (style.find('Sour') != -1):
            result = self.sour
        elif (style.find('White') != -1) or (style.find('Witte') != -1) or (style.find('Wheat') != -1) or (style.find('Weiss') != -1):
            result = self.white
        elif (style.find('Ale') != -1):
            result = self.ale
        else :
            result = 'Other'
        return result
    
    def numero_biere(self, style : str) -> int :
        result = ''
        if (style.find('Pils') != -1) or (style.find('Lager') != -1):
            result = 0.1
        elif (style.find('IPA') != -1) or (style.find('Indian Pale Ale') != -1) :
            result = 0.2
        elif (style.find('Saison') != -1) or (style.find('Season') != -1) :
            result = 0.3
        elif (style.find('Stout') != -1):
            result = 0.4
        elif (style.find('Porter') != -1):
            result = 0.5
        elif (style.find('Sour') != -1):
            result = 0.6
        elif (style.find('White') != -1) or (style.find('Witte') != -1) or (style.find('Wheat') != -1) or (style.find('Weiss') != -1):
            result = 0.7
        elif (style.find('Ale') != -1):
            result = 0.8
        else :
            result = 0.9
        return result