class ClassifieurBrewMethod:
    def __init__(self):
        self.all_grain = 0.1
        self.biab = 0.2
        self.extract = 0.3
        self.partial_mash = 0.4

    def numero_methode(self, methode : str) -> float :
        result = ''
        if (methode.find('All Grain') != -1):
            result = 0.1
        elif (methode.find('BIAB') != -1):
            result = 0.2
        elif (methode.find('extract') != -1):
            result = 0.3
        else :
            (methode.find('Partial Mash') != -1)
            result = 0.4
        return result
    