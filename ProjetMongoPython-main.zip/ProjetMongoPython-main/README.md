# MongoDB Project ACA
 
## Purpose
- This application solves specific issues related to salaries dataset.  

## Dependencies
-The file **requirements.in** set the dependencies and version requirements needed.
 
Follow he next steps to configure the use of the application.
 
## Configuration
Here are the steps to follow to run the application:
- You need to have access to a MongoDB database
- Create a virtual environment using "python -m venv 'your_environment_name'"
- Activate the environment by runing "your_environment_name/Scripts/activate" and you must be 
  located at the root of the project file
- Install the dependencies listed in requirements.in with "pip install -r requirements.in"
- Create your .env file as :
  "MONGO_HOST=localhost
   MONGO_PORT= 'your_mango_db_port'
   MONGO_DB_NAME=salaries"
- And then, insert it in the project file
- Replaces the XXX in .env file, by the corresponding fields
 
## How to use
To launch the application:
- Import the dataset by launching setup.py
- Run the application by launching main.py
 
## Troubleshooting
List here, the common issues that the users of your app can encounter.
- You may need to restart your IDE after importing the libraries
- setup.py needs to be launched only once!