# Here are your utils functions, globals...

SOLVABLE_ISSUES=['SalaryByGenderByEduLevel',
        'SalaryByGenderByYearsOfXp', 
        'Top100Salaries',
        'Bottom100Salaries', 
        'Top50SalariesByGender']