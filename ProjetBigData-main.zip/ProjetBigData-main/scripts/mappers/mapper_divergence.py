import sys

#Mapper
#Cette boucle itère sur chaque ligne lue depuis l'entrée standard
for line in sys.stdin:
    #Supprime les caractères d'espacement en début et fin de chaque ligne
    #Nettoie la ligne de tout espace inutile
    line = line.strip()
    #Cette ligne sépare la ligne en plusieurs éléments en utilisant la virgule
    #comme délimiteur. Cela transforme la ligne en une liste où chaque éléments
    #est une partie séparée par la virgule
    line = line.split(',')
    #Bloc try/except qui permettra de générer des exceptions qui pourraient 
    #se produire lors de la conversion des données ou de l'accès aux éléments de la liste
    #Si une exception se produit, le programme passe au bloc except sans planter, 
    #assurant ainsi la continuité du traitement des lignes suivantes.
    try:
        #La variable 'date' est assignée au premier élément de la liste
        date = line[0]
        #La variable différence est calculée en soustrayant la valeur du 2eme élément de la liste
        #du 5eme élément (prix d'ouverture - prix clôture)
        difference = float(line[4])-float(line[1])
        #La variable close est assignée à la valeur du 5eme élément de la liste
        close = float(line[4])
        #Création de la liste valeur contenant les valeurs calculées 'difference' et ' close'
        valeur = [difference,close]
        #Le résultat est imprimé sur la sortie standard
        #Où chaque ligne affiche la date suivie des valeurs de différence et de clôture
        print(f'{date},{valeur}')
    except:
        continue