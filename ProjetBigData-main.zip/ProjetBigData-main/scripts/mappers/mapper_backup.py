import sys

#Pour chaque ligne dans le système 
for line in sys.stdin:
    #Suppression des espaces dans la ligne
    line = line.strip()
    #Création d'une liste à partir des éléments de la ligne grace à une virgule comme séparateur
    line = line.split(',')

    #Assurer la continuité du programme en passant au Except si une erreur se produit dans le Try
    try:
        #La variable date correspond à la première valeur de la liste, soit la date et l'heure
        date = line[0]
        #La variable différence correspond à la différence entre la quatrième valeur de la liste 
        #et la première, soit la valeur du close moins la valeur du open
        difference = float(line[4])-float(line[1])
        #Le résultat est affiché sur la sortie standard
        print("%s,%s" % (date,difference))
    except:
        continue