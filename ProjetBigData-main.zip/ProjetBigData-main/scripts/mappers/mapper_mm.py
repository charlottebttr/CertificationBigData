import sys

#Pour chaque ligne dans le système 
for line in sys.stdin:
    #Suppression des espaces dans la ligne
    line = line.strip()
    #Création d'une liste à partir des éléments de la ligne grace à une virgule comme séparateur
    line = line.split(',')

    #Assurer la continuité du programme en passant au Except si une erreur se produit dans le Try
    try:
        #La variable date correspond à la première valeur de la liste, soit la date et l'heure
        date = line[0]
        #La variable close correspond à la quatrième valeur de la liste, soit le prix de clôture 
        close = float(line[4])
        #Le résultat est affiché sur la sortie standard
        print(f'{date},{close}')
    except:
        continue