import MT5singleton
import MetaTrader5 as mt5
import extracteur
import os

#Ici nous présentons une 'application' qui permet à l'utilisateur de récupérer des données 
#historiques à partir de la plateforme #Metatrader 5, pour certains instruments financiers, 
#ici nous allons utiliser les paires de devises majeures (Forex).

#Définition des variables globales
#L'utilisateur peut choisir des options et modifier les données d'entrée s'il le souhaite
MESSAGE_USER_INPUT = """Vous pouvez :
Changer l'instrument de mesure, tappez l'instrument [I]
Changer le paramétrage de l'intervalle de temps, tappez [T]
Changer le nombre d'observations à récolter, tappez [O]
Lancer la récupération des données, tappez [S]
Récupérer 'toutes' les données, tappez [ALL]
Quitter le programme, tappez [Q] 
"""
#Chemin du fichier de données historiques
HISTORICAL_FILE_PATH = './assets/historical_data.csv'
#Liste des instruments majeurs utilisables
MAJOR_INSTRUMENTS = ['EURUSD','EURGBP','EURCAD','EURCHF','EURJPY']
#Chemin du dossier pour stocker les fichiers de données historiques pour chaque instrument majeur
MAJOR_INSTRUMENTS_FILE_PATH = './assets/'

#Initialisation des variables
#Ici la paire Euro, Dollar américain est utilisée par défaut
INSTRUMENT = 'EURUSD'
#Définition de l'intervalle de temps entre chaque observation
#(M1-M5-M15-M30-H1-H4-D1-W1-M1)
INTERVALLE = mt5.TIMEFRAME_H1
#Position actuelle (aujourd'hui) = 0
POSITION_ARRIVEE = 0
#Nombre d'observations à réccupérer
NOMBRE_OBSERVATIONS = 1000

#Le singleton est utilisé pour gérer une connexion unique à MT5
connexionMT5 = MT5singleton.MT5Singleton.get_instance()

#Interaction Utilisateur:
#On demande à l'utilisateur de saisir des commandes via la console. Il peut choisir différentes 
#options en fonction des lettres proposées afin de modifier les données d'entrée et les mettre à jour
user_input = input(MESSAGE_USER_INPUT)
while(user_input!='Q'):
    match user_input:
        #Changer l'instrument de mesure
        case 'I':
            INSTRUMENT = input('Nouvel instrument : ')
            print('Le nouvel instrument :',INSTRUMENT,'a bien été pris en compte')
        #Changer l'intervalle de temps
        case 'T':
            INTERVALLE = input('Nouvel intervalle : ')
            print('Le nouvel intervalle :',INTERVALLE,'a bien été pris en compte')
        #Changer le nombre d'observations à récolter
        case 'O':
            try:
                NOMBRE_OBSERVATIONS = int(input('Nouvelle quantité d\'observations : '))
                print('La nouvelle quantité d\'observations :',NOMBRE_OBSERVATIONS,'a bien été prise en compte')
            except:
                print('Le format du nombre d\'observations attendu est un nombre : ')
                pass
        #Lancer la réccupération de données pour un seul instrument 
        #Puis sauvegarde les données dans un fichier CSV spécifié 
        case 'S':
            ex = extracteur.Extracteur()
            df_historique = ex.extract_historical_data(INSTRUMENT, INTERVALLE, POSITION_ARRIVEE, NOMBRE_OBSERVATIONS)
            if(os.path.exists(HISTORICAL_FILE_PATH)):
                os.remove(HISTORICAL_FILE_PATH)
            df_historique.to_csv(HISTORICAL_FILE_PATH,index=False)
        #Effectue la même opération pour chaque instrument majeur
        case 'ALL':
            ex = extracteur.Extracteur()
            for instrument in MAJOR_INSTRUMENTS:
                if(os.path.exists((MAJOR_INSTRUMENTS_FILE_PATH+f'{instrument}.csv'))):
                    os.remove((MAJOR_INSTRUMENTS_FILE_PATH+f'{instrument}.csv'))
                df = ex.extract_historical_data(instrument, INTERVALLE, POSITION_ARRIVEE, NOMBRE_OBSERVATIONS)
                df.to_csv((MAJOR_INSTRUMENTS_FILE_PATH+f'{instrument}.csv'),index=False)
        #Affiche le message de sortie et sort de la boucle
        case 'Q':
            print('Bonne journée !')
            break
        case _:
            user_input = input("Je n'ai pas compris votre demande, veuillez ressaisir votre demande : ")
    user_input = input(MESSAGE_USER_INPUT)