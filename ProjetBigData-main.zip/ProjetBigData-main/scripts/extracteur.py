import MetaTrader5 as mt5
import pandas as pd


class Extracteur:

    def __init__(self) -> None:
        pass

    '''Extrait les données historiques selon paramétrage
    @instrument : l'instrument à extraire
    @intervale : l'intervale de temps entre chaque observation
    @position_actuelle : jusqu'où allons-nous récupérer les données historiques
    @nombre_observations : la quantité d'observations à extraire
    @return un Dataframe avec les données historiques extraites'''

    def extract_historical_data(self, instrument: str, intervale: object, position_actuelle: int, nombre_observation: int) -> pd.DataFrame:
        #Cette ligne de code appelle la fonction copy_rates_from_pos de la bibliothèque MetaTrader5 
        #avec les paramètres spécifiés. La fonction retourne les données historiques sous forme de 
        #liste de dictionnaires, où chaque dictionnaire représente une bougie/candle et contient les
        #informations suivantes : 'time' (timestamp de la bougie), 'open' (prix d'ouverture de la bougie),
        #'high' (prix le plus haut de la bougie), 'low' (prix le plus bas de la bougie) et 'close'
        #(prix de clôture de la bougie).
        bars = mt5.copy_rates_from_pos(instrument, intervale, position_actuelle, nombre_observation)
        print('Loading...')
        #Crée un dataframe à partir des noms des colonnes imposées par MT5
        df = pd.DataFrame(bars)[['time', 'open', 'high', 'low', 'close']]
        #Convertie la colonne "time" du DataFrame en objets de type datetime
        df['time'] = pd.to_datetime(df['time'], unit='s')
        print(df.head())
        print('Extraction terminée')
        return df
