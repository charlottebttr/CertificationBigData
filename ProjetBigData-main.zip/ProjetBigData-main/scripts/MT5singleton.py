import MetaTrader5 as mt5

#Classe définissant le modèle Singleton pour la connexion MT5. 
#Le modèle Singleton garantit qu'une seule instance de la classe est 
#créée pendant toute la durée d'exécution du programme.
class MT5Singleton:
    #Variable de classe qui stockera l'unique instance de la classe MT5Singleton.
    __instance = None
    #La méthode suivante est une méthode statique, c'est-à-dire qu'elle peut être 
    #appelée directement depuis la classe sans avoir besoin d'une instance de la classe.
    @staticmethod
    def get_instance():
        if MT5Singleton.__instance is None:
            MT5Singleton()
        return MT5Singleton.__instance
    #Si aucune autre instance n'existe, initialise la connextion avec MT5
    def __init__(self):
        if MT5Singleton.__instance is not None:
            raise Exception("Ce Singleton est déjà instancié ! Utilisez la méthode get_instance().")
        #Définition des informations d'identification pour se connecter au compte 
        #qui nous permettra de tirer les données de pricing du courtier correspondant
        else:
            MT5Singleton.__instance = self
            mt5.initialize()
            login = 5888402
            password = 'EBOKvxon'
            server = 'ActivTradesCorp-Server'
            mt5.login(login, password, server)
            #Affichage des informations d'identification au terminal et la version de la bibliothèque MT5
            print(mt5.terminal_info(),mt5.version())