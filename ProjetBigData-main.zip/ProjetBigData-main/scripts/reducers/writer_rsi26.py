import happybase as hb

class Writer_rsi26:

    def __init__(self):
        self.adresse = 'localhost'
        self.port = 9090
        self.related_table = 'rsi26'
        self.families = {
            'time': {},
            'rsi' : {}
        }
        self.db = hb.Connection(self.adresse,self.port)
        self.db.open()

    def table_exists(self):
        if(self.related_table.encode() in self.db.tables()):
            return True
        else:
            return False
    
    def clean_hbase(self):
        self.db.disable_table(self.related_table)
        self.db.delete_table(self.related_table)
        self.db.create_table(self.related_table,families=self.families)

    def write_in_hbase(self, ligne : list):
        if(not self.table_exists()):
            self.db.create_table(self.related_table,families=self.families)

        #Insertion de la ligne dans la base
        self.db.table(self.related_table).put(ligne[-1],{b'time:col1':ligne[0],b'rsi:col1':ligne[1]})