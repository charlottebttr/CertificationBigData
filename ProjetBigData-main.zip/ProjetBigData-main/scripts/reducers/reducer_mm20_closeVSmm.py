import sys
from writers import writer_mm20_closeVSmm as writer
import csv
import os

PERIODE = 20
position = 0
donnees_conservees = []

DATA = [['time','close','mm20','signal']]

hb_writer = writer.Writer_mm20_closeVSmm()
if(hb_writer.table_exists()):
    hb_writer.clean_hbase()

for line in sys.stdin:
    position +=1
    line = line.strip()
    ligne = line.split(',')
    if(position<=PERIODE):
        donnees_conservees.append(ligne)
        ligne.append(0)
        ligne.append('')
    else:
        cumul_close = 0
        donnees_conservees.append(ligne)
        donnees_conservees.pop(0)
        for ligne_stockee in donnees_conservees:
            cumul_close += float(ligne_stockee[1])
        moyenne_mobile_periode = (cumul_close/PERIODE)
        ligne.append(round(moyenne_mobile_periode,4))

        #Calculs stratégiques
        if(float(ligne[1])>ligne[2]):
            ligne.append('BUY')
        elif(float(ligne[1])<ligne[2]):
            ligne.append('SELL')
        else:
            ligne.append('HOLD')
    
    #Row_ID
    row_id = ligne[0].replace('-','').replace(' ','').replace(':','')
    ligne.append(row_id)

    hb_writer.write_in_hbase(ligne)

    print(ligne)

    DATA.append([ligne[0],ligne[1],ligne[2],ligne[3]])

os.makedirs('assets\\results', exist_ok=True)
with open('assets\\results\\EURCADmmclosevsmm.csv', 'w', newline='') as fichier:
    writer = csv.writer(fichier)
    writer.writerows(DATA)