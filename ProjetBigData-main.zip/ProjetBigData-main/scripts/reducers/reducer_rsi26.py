import sys
from writers import writer_rsi26 as writer
import csv
import os

#Initialisation de la constance Periode à 26
PERIODE = 26
#Initialisation de la variable position à 0
position = 0
#Création d'une liste pour stocker les données conservées
donnees_conservees = []
#Initialisation de la liste Data avec une sous-liste avec la date et le RSI 
DATA = [['time','rsi']]

#Instanciation d'une classe servant à écrire des données dans une base de données NoSQL Hbase
hb_writer = writer.Writer_rsi26()
#Si la table existe déjà dans la base, on nettoie la table 
if(hb_writer.table_exists()):
    hb_writer.clean_hbase()

#Pour chaque ligne dans le système 
for line in sys.stdin:
    #Incrémentation de 1 à la valeur actuelle de la variable position
    position +=1
    #Suppression des espaces dans la ligne
    line = line.strip()
    #Création d'une liste à partir des éléments de la ligne grace à une virgule comme séparateur
    ligne = line.split(',')
    #Si la position est inférieure ou égale à la constance période 
    if(position<=PERIODE):
        #Si le deuxième élément de la liste, soit la différence entre close et open, est positif ou nul
        if(float(ligne[1])>=0):
            #La valeur de cet élément est ajoutée à la fin de la liste sous forme décimale
            ligne.append(float(ligne[1]))
            #Une chaine de caractère '0' est ajoutée à la fin de la liste ligne
            ligne.append('0')
        #Si le deuxième élément de la liste, soit la différence entre close et open, est négatif
        else:
            #Une chaine de caractère '0' est ajoutée à la fin de la liste ligne
            ligne.append('0')
            #La valeur de cet élément est ajoutée à la fin de la liste sous forme de décimale négative
            ligne.append(-float(ligne[1]))
        #Chaque ligne modifiée est ajoutée aux données conservées 
        donnees_conservees.append(ligne)
        #Quatre 0 sont ajoutés à la fin de chaque liste afin de respecter le même nombre de caractères 
        #par liste, notamment pour les 26 premières lignes qui n'ont pas encore les données de calcul
        ligne.append(0)
        ligne.append(0)
        ligne.append(0)
        ligne.append(0)
    #Si la position est supérieure ou égale à la constance période
    else:
        #Si le deuxième élément de la liste, soit la différence entre close et open, est positif ou nul
        if(float(ligne[1])>=0):
            #La valeur de cet élément est ajoutée à la fin de la liste sous forme décimale
            ligne.append(float(ligne[1]))
            #Une chaine de caractère '0' est ajoutée à la fin de la liste ligne
            ligne.append('0')
        #Si le deuxième élément de la liste, soit la différence entre close et open, est négatif
        else:
            #Une chaine de caractère '0' est ajoutée à la fin de la liste ligne
            ligne.append('0')
            #La valeur de cet élément est ajoutée à la fin de la liste sous forme de décimale négative
            ligne.append(-float(ligne[1]))

        #Initialisation des variables cumul_gain et cumul_perte à 0
        cumul_gain = 0
        cumul_perte = 0
        #Chaque ligne modifiée est ajoutée aux données conservées pour la période en cours
        donnees_conservees.append(ligne)
        #La première ligne de données est supprimée 
        donnees_conservees.pop(0)
        #Pour chaque ligne de nos données conservées
        for ligne_stockee in donnees_conservees:
            #Initialisation de la variable ponderation à 1
            ponderation = 1
            #Ajout au cumul gain, le produit de la troisième valeur soit le gain, avec le ratio de 
            #la ponderation sur la periode
            cumul_gain += float(ligne_stockee[2])*(ponderation/PERIODE)
            #Ajout au cumul perte, le produit de la quatrième valeur soit la perte, avec le ratio de 
            #la ponderation sur la periode
            cumul_perte += float(ligne_stockee[3])*(ponderation/PERIODE)
            #Incrémentation de 0.1 à la valeur actuelle de la variable ponderation
            ponderation +=0.1
        #Calcul de la moyenne des gains    
        moyenne_gain_periode = (cumul_gain/PERIODE)
        #Calcul de la moyenne des pertes
        moyenne_perte_periode = (cumul_perte/PERIODE)
        #La valeur de la moyenne des gains est ajoutée à la suite de la liste, soit au niveau 
        #du cinquième élément 
        ligne.append(moyenne_gain_periode)
        #La valeur de la moyenne des pertes est ajoutée à la suite de la liste, soit au niveau 
        #du sixième élément 
        ligne.append(moyenne_perte_periode)
        #Calcul du ratio de la moyenne des gains sur la moyenne des pertes, soit le RS
        ligne.append(moyenne_gain_periode/moyenne_perte_periode)
        #Calcul du RSI, Indicateur de Force Relative
        ligne.append(round(100 - (100 / ((moyenne_gain_periode/moyenne_perte_periode) + 1)),2))
    
    #Création de notre clé valeur Row_ID à partir de la date, en supprimant les éléments suivants :
    #espaces, deux points et tirets
    row_id = ligne[0].replace('-','').replace(' ','').replace(':','')
    #La valeur du Row_ID nouvellement généré est ajouté à la fin de la liste
    ligne.append(row_id)

    #Ecriture de la ligne dans Hbase
    hb_writer.write_in_hbase(ligne)

    #Les valeurs de la date et du RSI sont ajoutées dans la sous-liste de la liste DATA 
    DATA.append([ligne[0],ligne[7]])

    #Affiche la réussite
    print('OK')

#Génération d'un fichier csv avec les nouvelles données générées
os.makedirs('assets\\results', exist_ok=True)
with open('assets\\results\\EURCADrsi26.csv', 'w', newline='') as fichier:
    writer = csv.writer(fichier)
    writer.writerows(DATA)
