import sys

PERIODE = 26
position = 0
donnees_conservees = []

#Variables Stratégiques
DUO_CLOSE = [0,0]
DUO_RSI = [0,0]
position_plage = 0
TAILLE_PLAGE = 100

for line in sys.stdin:
    position +=1
    position_plage +=1
    
    line = line.strip()
    ligne = line.split(',')
    ligne[1] = ligne[1].replace('[','')
    ligne[2] = ligne[2].strip().replace(']','')

    if(position<=PERIODE):

        if(position_plage==1):
            DUO_CLOSE[0]=float(ligne[2])
        elif(position_plage==TAILLE_PLAGE+1):
            DUO_CLOSE[1]=float(ligne[2])

        if(float(ligne[1])>=0):
            ligne.append(float(ligne[1]))
            ligne.append('0')
        else:
            ligne.append('0')
            ligne.append(-float(ligne[1]))
        donnees_conservees.append(ligne)
        ligne.append(0)
        ligne.append(0)
        ligne.append(0)
        ligne.append(0)
        ligne.append('')

    else:
        if(float(ligne[1])>=0):
            ligne.append(float(ligne[1]))
            ligne.append('0')
        else:
            ligne.append('0')
            ligne.append(-float(ligne[1]))
        cumul_gain = 0
        cumul_perte = 0
        donnees_conservees.append(ligne)
        donnees_conservees.pop(0)
        for ligne_stockee in donnees_conservees:
            ponderation = 1
            cumul_gain += float(ligne_stockee[3])*(ponderation/PERIODE)
            cumul_perte += float(ligne_stockee[4])*(ponderation/PERIODE)
            ponderation +=0.1
        moyenne_gain_periode = (cumul_gain/PERIODE)
        moyenne_perte_periode = (cumul_perte/PERIODE)
        ligne.append(moyenne_gain_periode)
        ligne.append(moyenne_perte_periode)
        ligne.append(moyenne_gain_periode/moyenne_perte_periode)
        ligne.append(round(100 - (100 / ((moyenne_gain_periode/moyenne_perte_periode) + 1)),2))
        
        if(position_plage==1):
            DUO_RSI[0]=float(ligne[8])
        elif(position_plage==TAILLE_PLAGE+1):
            DUO_RSI[1]=float(ligne[8])

        #Calculs stratégiques
        if(position_plage==TAILLE_PLAGE+1):
            if((DUO_CLOSE[0]>DUO_CLOSE[1])&(DUO_RSI[0]<DUO_RSI[1])):
                ligne.append('BUY')
            elif((DUO_CLOSE[0]<DUO_CLOSE[1])&(DUO_RSI[0]>DUO_RSI[1])):
                ligne.append('SELL')
            position_plage=0
        #Deuxième implémentation
        # if(position>PERIODE+3):
        #     if(((donnees_conservees[-2][2]>donnees_conservees[-1][2]) & (donnees_conservees[-2][8]>donnees_conservees[-1][8]))&()):
        #         ligne.append('BUY')
        #     elif((DUO_CLOSE[0]<DUO_CLOSE[1])&(DUO_RSI[0]>DUO_RSI[1])):
        #         ligne.append('SELL')

    #Row_ID
    row_id = ligne[0].replace('-','').replace(' ','').replace(':','')
    ligne.append(row_id)
    print(ligne)