import sys
from writers import writer_mm20 as writer
import csv
import os

#Initialisation de la constance Periode à 20
PERIODE = 20
#Initialisation de la variable position à 0
position = 0
#Création d'une liste pour stocker les données conservées
donnees_conservees = []
#Initialisation de la liste Data avec une sous-liste avec la date et le RSI 
DATA = [['time','moyenne_mobile']] 

#Instanciation d'une classe servant à écrire des données dans une base de données NoSQL Hbase
hb_writer = writer.Writer_mm20()
#Si la table existe déjà dans la base, on nettoie la table 
if(hb_writer.table_exists()):
    hb_writer.clean_hbase()

for line in sys.stdin:
    position +=1
    line = line.strip()
    ligne = line.split(',')
    if(position<=PERIODE):
        donnees_conservees.append(ligne)
        ligne.append(0)
    else:
        cumul_close = 0
        donnees_conservees.append(ligne)
        donnees_conservees.pop(0)
        for ligne_stockee in donnees_conservees:
            cumul_close += float(ligne_stockee[1])
        moyenne_mobile_periode = (cumul_close/PERIODE)
        ligne.append(round(moyenne_mobile_periode,4))

    #Création de notre clé valeur Row_ID à partir de la date, en supprimant les éléments suivants :
    #espaces, deux points et tirets
    row_id = ligne[0].replace('-','').replace(' ','').replace(':','')
    #La valeur du Row_ID nouvellement généré est ajouté à la fin de la liste
    ligne.append(row_id)

    #Ecriture de la ligne dans Hbase
    hb_writer.write_in_hbase(ligne)

    #Les valeurs de la date et de la moyenne mobile sont ajoutées dans la sous-liste de la liste DATA
    DATA.append([ligne[0],ligne[2]])
    
    #Affiche la ligne avec la moyenne mobile
    print(ligne)

#Génération d'un fichier csv avec les nouvelles données générées 
os.makedirs('assets\\results', exist_ok=True)
with open('assets\\results\\EURCADmm20.csv', 'w', newline='') as fichier:
    writer = csv.writer(fichier)
    writer.writerows(DATA)