import sys
from writers import writer_strat7030_rsi26 as writer
import csv
import os

#Initialisation de la constance Periode à 26
PERIODE = 26
#Initialisation de la variable position à 0
position = 0
#Création d'une liste pour stocker les données conservées
donnees_conservees = []
#Initialisation de la liste Data avec une sous-liste avec la date et le RSI 
DATA = [['time','rsi','signal']] 

#Instanciation d'une classe servant à écrire des données dans une base de données NoSQL Hbase
hb_writer = writer.Writer_strat7030_rsi26()
#Si la table existe déjà dans la base, on nettoie la table 
if(hb_writer.table_exists()):
    hb_writer.clean_hbase()

for line in sys.stdin:
    position +=1
    line = line.strip()
    ligne = line.split(',')
    if(position<=PERIODE):
        if(float(ligne[1])>=0):
            ligne.append(float(ligne[1]))
            ligne.append('0')
        else:
            ligne.append('0')
            ligne.append(-float(ligne[1]))
        donnees_conservees.append(ligne)
        ligne.append(0)
        ligne.append(0)
        ligne.append(0)
        ligne.append(0)
        ligne.append('')
    else:
        if(float(ligne[1])>=0):
            ligne.append(float(ligne[1]))
            ligne.append('0')
        else:
            ligne.append('0')
            ligne.append(-float(ligne[1]))
        cumul_gain = 0
        cumul_perte = 0
        donnees_conservees.append(ligne)
        donnees_conservees.pop(0)
        for ligne_stockee in donnees_conservees:
            ponderation = 1
            cumul_gain += float(ligne_stockee[2])*(ponderation/PERIODE)
            cumul_perte += float(ligne_stockee[3])*(ponderation/PERIODE)
            ponderation +=0.1
        moyenne_gain_periode = (cumul_gain/PERIODE)
        moyenne_perte_periode = (cumul_perte/PERIODE)
        ligne.append(moyenne_gain_periode)
        ligne.append(moyenne_perte_periode)
        ligne.append(moyenne_gain_periode/moyenne_perte_periode)
        ligne.append(round(100 - (100 / ((moyenne_gain_periode/moyenne_perte_periode) + 1)),2))
        
        #Calculs stratégiques
        if(position>PERIODE):
            if(float(ligne[7])<=30):
                ligne.append('BUY')
            elif(float(ligne[7])>=70):
                ligne.append('SELL')
            else:
                ligne.append('HOLD')
    
    #Création de notre clé valeur Row_ID à partir de la date, en supprimant les éléments suivants :
    #espaces, deux points et tirets
    row_id = ligne[0].replace('-','').replace(' ','').replace(':','')
    #La valeur du Row_ID nouvellement généré est ajouté à la fin de la liste
    ligne.append(row_id)

    #Ecriture de la ligne dans Hbase
    hb_writer.write_in_hbase(ligne)
    
    #Les valeurs de la date, du RSI et du signal sont ajoutées dans la sous-liste de la liste DATA
    DATA.append([ligne[0],ligne[7],ligne[8]])

    #Affiche la ligne avec le RSI et le signal 
    print(ligne)

#Génération d'un fichier csv avec les nouvelles données générées 
os.makedirs('assets\\results', exist_ok=True)
with open('assets\\results\\EURCADstrat7030rsi26.csv', 'w', newline='') as fichier:
    writer = csv.writer(fichier)
    writer.writerows(DATA)