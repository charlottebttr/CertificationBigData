import sys
from writers import writer_mm_crossover as writer
import csv
import os

#Ce reducer effectue des calculs sur les moyennes mobiles des périodes courtes et longues,
#détermine les actions stratégiques à prendre (acheter, vendre, conserver) et enregistre 
#les résultats dans une base de données HBase.

#Définition des constantes qui déterminent les périodes de calcul des moyennes mobiles.
PERIODE_COURTE = 20
PERIODE_LONGUE = 50
#Position actuelle dans les données, servira à compter les lignes traitées
position = 0
#Listes vides qui seront utilisées pour stocker les données des moyennes mobiles
#Permettont de conserver les données nécessaires pour calculer les moyennes mobiles
donnees_conservees_periode_courte = []
donnees_conservees_periode_longue = []

DATA = [['time','close','mm20','mm50','signal']]

#Instance du writer, classe personnalisée servant à écrire les données dans HBase
hb_writer = writer.Writer_mm_crossover()
#Cette partie vient vérifier si la table existe déja dans HBase et, si c'est le cas 
#nettoie la table si les données sont existantes
if(hb_writer.table_exists()):
    hb_writer.clean_hbase()

#Itère sur chaque ligne lue depuis l'entrée (stdin) contenant les résultats du mappage
for line in sys.stdin:
    #Parcours de chaque ligne
    position +=1
    #Suppression des caractères d'espacement
    line = line.strip()
    #Split des lignes en plusieurs éléments, utilisant le (',') comme séparateur
    #Cela transforme la ligne en une liste où chaque élément est une partie séparée par la virgule 
    ligne = line.split(',')
    #Traitements en fonction de la position dans les données
    #Si la position est inférieure ou égale à la période courte
    if(position<=PERIODE_COURTE):
        #Ajout de la ligne aux listes
        donnees_conservees_periode_longue.append(ligne)
        donnees_conservees_periode_courte.append(ligne)
        #Ajout également de 3 élements à la fin de chaque ligne, deux zéros une chaîne de vide
        ligne.append(0)
        ligne.append(0)
        ligne.append('')
    else:
        #Si la position est supérieure à la période courte
        #Cette variable servira à stocker la somme cumulative des prix de clôture des bougies 
        #sur la période courte qui sera utilisée pour calculer la moyenne mobile
        cumul_close_periode_courte = 0
        donnees_conservees_periode_courte.append(ligne)
        #Suppression de la premiere ligne
        donnees_conservees_periode_courte.pop(0)
        for ligne_stockee in donnees_conservees_periode_courte:
            #A chaque itération de la boucle, le prix de clôture de la bougie 
            #est converti en nombre flottant puis ajouté à la variable cumul close période courte
            cumul_close_periode_courte += float(ligne_stockee[1])
        #Calcul de la moyenne mobile de la période courte en utilisant les données conservées
        moyenne_mobile_periode_courte = (cumul_close_periode_courte/PERIODE_COURTE)
        #Ajout de la ligne aux listes données conservées période longue
        donnees_conservees_periode_longue.append(ligne)
        #Si la position est supérieure à la période longue
        if(position>PERIODE_LONGUE):
            #Suppression du premier élément de la liste
            donnees_conservees_periode_longue.pop(0)
        #La moyenne mobile période courte est ajoutée à la ligne
        ligne.append(round(moyenne_mobile_periode_courte,4))

        if(position>PERIODE_LONGUE):
            #Cette variable servira à stocker la somme cumulative des prix de clôture des bougies 
            #sur la période longue
            cumul_close_periode_longue = 0
            for ligne_stockee in donnees_conservees_periode_longue:
                #A chaque itération de la boucle, le prix de clôture de la bougie est converti
                #en nombre flottant puis ajouté à la variable cumul close période longue
                cumul_close_periode_longue += float(ligne_stockee[1])
            #Calcul de la moyenne mobile période longue
            moyenne_mobile_periode_longue = (cumul_close_periode_longue/PERIODE_LONGUE)
            #La moyenne mobile période courte est ajouté à la ligne
            ligne.append(round(moyenne_mobile_periode_longue,4))
        else:
            #Ajout d'un zéro et d'une chaîne vide sur la ligne
            ligne.append(0)
            ligne.append('')

        #Calculs stratégiques pour déterminer si l'action doit être "BUY", "SELL"ou "HOLD". 
        #Ces calculs sont basés sur les valeurs des colonnes de la ligne
        #(les colonnes 2 et 3, prix d'ouverture et de clôture)
        if(position>PERIODE_LONGUE):
            if(float(ligne[2])>ligne[3]):
                ligne.append('BUY')
            elif(float(ligne[2])<ligne[3]):
                ligne.append('SELL')
            else:
                ligne.append('HOLD')
    
    #Row_ID servant d'identifiant de ligne, en formatant la date, premier élément de chaque ligne.
    #Les caractères "-", " ", et ":" sont remplacés par une chaine vide pour obtenir un ID propre.
    row_id = ligne[0].replace('-','').replace(' ','').replace(':','')
    #Ajoute ce Row_ID à la fin de chaque ligne
    ligne.append(row_id)
    #Ecrit la ligne dans HBase
    hb_writer.write_in_hbase(ligne)
    #Affiche la ligne (stout) avec le résultats de calculs stratégiques ajoutés
    print(ligne)

    DATA.append([ligne[0],ligne[1],ligne[2],ligne[3],ligne[4]])

os.makedirs('assets\\results', exist_ok=True)
with open('assets\\results\\EURCADmmcross.csv', 'w', newline='') as fichier:
    writer = csv.writer(fichier)
    writer.writerows(DATA)