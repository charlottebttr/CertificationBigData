# ProjetBigData
## Réalisé par Charlotte Bouttier - Assad Kleit - Adrien Dehais

# Requirements
Pour éxécuter ce programme, il est nécessaire de suivre les étapes suivantes :
- MT5
- Compte de trading
- Cloner ce Git
- Création de l'environnement local grâce à : python -m venv myenv
- Activation de l'environnement local : .\myenv\Scripts\activate.ps1
- librairies
    - MetaTrader5
    - pandas
    - happybase
    - csv

# Docker
- Télécharger Docker Desktop
- Mettre à jour WSL: wsl --update
- Mettre WSL en version 2: wsl --set-default-version 2
- Relancer le terminal et docker Desktop
- Vérifier que la distribution dockerdesktop est installé: wsl -l -v
La sortie:
  NAME                   STATE           VERSION
* docker-desktop         Running         2
  docker-desktop-data    Running         2

- tester un container:
docker run -ti --name=alpine0 alpine
- sortir du container: exit
- supprimer le container: docker rm alpine0

docker pull liliasfaxi/spark-hadoop:hv-2.7.2

docker network create --driver=bridge hadoop

docker run -itd --net=hadoop -p 9070:50070 -p 8088:8088 -p 7077:7077 -p 16010:16010 -p 9090:9090 --name hadoop-master --hostname hadoop-master liliasfaxi/spark-hadoop:hv-2.7.2

docker run -itd -p 8040:8042 --net=hadoop --name hadoop-slave1 --hostname hadoop-slave1 liliasfaxi/spark-hadoop:hv-2.7.2

docker run -itd -p 8041:8042 --net=hadoop --name hadoop-slave2 --hostname hadoop-slave2 liliasfaxi/spark-hadoop:hv-2.7.2

docker exec -it hadoop-master bash

./start-hadoop.sh

cp /usr/local/hadoop/share/hadoop/tools/lib/hadoop-streaming-2.7.2.jar .

exit

Depuis la racine du projet :
docker cp setup.sh hadoop-master:/root/setup.sh
docker cp hbase_drop.sh hadoop-master:/root/hbase_drop.sh
docker cp hbase.sh hadoop-master:/root/hbase.sh
docker cp happybase.sh hadoop-master:/root/happybase.sh

docker exec -it hadoop-master bash

apt-get update
apt-get -f install
apt-get upgrade -y
apt-get install python3-pip -y
/usr/bin/python3 -m pip install happybase

./hbase_drop.sh
./hbase.sh
./happybase.sh

hadoop fs -mkdir -p input
hadoop fs -mkdir -p output

hadoop jar hadoop-streaming-2.7.2.jar -file ProjetBigData/scripts/mappers/mapper.py -mapper "python3 mapper.py" -file ProjetBigData/scripts/reducers/reducer_rsi26.py -reducer "python3 reducer_rsi26.py" -input ProjetBigData/assets/EURCAD.csv -output /output/ProjetBigData/results
