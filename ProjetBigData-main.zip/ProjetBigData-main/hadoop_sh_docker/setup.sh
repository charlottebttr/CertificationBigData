apt-get update
apt-get -f install
apt-get upgrade -y
apt-get install python3-pip -y
/usr/bin/python3 -m pip install happybase

./hbase_drop.sh
./hbase.sh
./happybase.sh


